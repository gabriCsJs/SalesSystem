﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace SalesSystem
{
    public partial class frmLogin : Form
    {
        private bool validacao(string v_Username, string v_Password)
        {
            string usuario_banco = "";
            string senha_banco = "";
                
            //ATENÇAO VEREFICAR O CAMINHO DO CAMPO ABAIXO
            string Sql = @"select id_usuario, Nome_usuario, Senha_u from tbl_usuario
                          where Nome_usuario = '" + v_Username + " ' and Senha_u = '" + v_Password + " ' ";

            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(Sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                usuario_banco = dt.Rows[0]["Nome_usuario"].ToString();
                senha_banco = dt.Rows[0]["Senha_u"].ToString();
            }

            if (v_Username == usuario_banco && v_Password == senha_banco && v_Username != string.Empty)
            {
                return true;
            }

            else
            {
                MessageBox.Show("Usuario / senha invalidos", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUser.Focus();
            }
            return false;
        }

        public frmLogin()
        {
            InitializeComponent();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Fecha A aplicação
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!(txtUser.Text.Equals(string.Empty) || (lable.Text.Equals(string.Empty))))
            {
                string c_senha = txtSenha.Text.Replace(" ' ", " ");
                string c_usuario = txtUser.Text.Replace(" ' ", " ");

                if (!validacao(c_usuario, c_senha))
                {
                    return;
                }
            }
            else
            {
                MessageBox.Show("Ha campos em branco", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            this.Close();
        }
    }
}
