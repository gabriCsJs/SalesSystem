﻿using SalesSystem.cadastro;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace SalesSystem
{
    public partial class frmHome : Form
    {
        public frmHome()
        {
            InitializeComponent();
        }

        private void centralizarimagem()
        {
            int x = (this.Width / 2) - (logo1.Width / 2);
            int y = (this.Height / 2) - ((logo1.Height - 15) / 2);
            logo1.Location = new Point(x, y);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            
            SalesSystem.Clases.db.abrebanco();

            centralizarimagem();

            frmLogin login = new frmLogin();
            login.ShowDialog();

        }

        private void logo1_Resize(object sender, EventArgs e)
        {
            
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            centralizarimagem();
        }

        private void logo1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            centralizarimagem();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void categoriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCategoria categoria = new frmCategoria();
            categoria.ShowDialog();
        }

        private void calculadoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc");
        }

        private void wordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("winword");
        }

        private void exelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("excel");
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            frmCategoria categoria = new frmCategoria();
            categoria.ShowDialog();
        }
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            frmProdutos produto = new frmProdutos();
            produto.ShowDialog();
        }
        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            frmFornecedorCadastro fornecedor = new frmFornecedorCadastro();
            fornecedor.ShowDialog();
        }
        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            frmClienteCadastro cli = new frmClienteCadastro();
            cli.ShowDialog();
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            frmFuncionarios user = new frmFuncionarios();
            user.ShowDialog();
        }
        private void toolStripButton7_Click(object sender, EventArgs e)
        {

        }
        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc");
        }
        private void toolStripButton8_Click(object sender, EventArgs e)
        {

        }
        private void toolStripButton4_Click(object sender, EventArgs e)
        {

        }

        private void produtosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProdutos produto = new frmProdutos();
            produto.ShowDialog();
        }

        private void fornecedoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFornecedorCadastro fornecedor = new frmFornecedorCadastro();
            fornecedor.ShowDialog();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmClienteCadastro cli = new frmClienteCadastro();
            cli.ShowDialog();
        }

        private void usuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFuncionarios user = new frmFuncionarios();
            user.ShowDialog();
        }

        private void marcaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMarca marca = new frmMarca();
            marca.ShowDialog();
        }
    }
}
