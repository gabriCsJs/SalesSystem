﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{
    public partial class frmFuncionariosPesquisa : Form
    {
        public frmFuncionariosPesquisa()
        {
            InitializeComponent();
        }

        public int funcionario { get; set; }


        private void frmFuncionariosPesquisa_Load(object sender, EventArgs e)
        {

        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            string sql = @"select * from tbl_usuario where (Nome_usuario like '%" + txtLocalizar.Text + "% ')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            dataGridView1.DataSource = dt;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                this.funcionario = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            }

            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
