﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SalesSystem.Clases
{
    class Util
    {
        public static bool isNumber(string numero)
        {
            try
            {
                double n = Convert.ToDouble(numero);
            }
            catch 
            {
                return false;
            }
            return true;
        }

        public static bool SoNumeros(System.Windows.Forms.TextBox CaixaTexto, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == 8)
            {
                e.Handled = false;
                return e.Handled;
            }
            
            if (e.KeyChar == '.')
            {
                e.KeyChar = ',';
            }

            bool IsDec = false;

            int nroDec = 0;

            for (int i = 0; i < CaixaTexto.Text.Length; i++)
            {
                if (CaixaTexto.Text[i] == ',')
                    IsDec = true;
                if (IsDec && nroDec++ >= 2)
                {
                    if (CaixaTexto.SelectionLength != CaixaTexto.Text.Length)
                    {
                        e.Handled = true;
                        return e.Handled;
                    }
                }
            }

            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = false;
            }

            else if (e.KeyChar == 44)
            {
                e.Handled = (IsDec) ? true : false;
            }

            else
            {
                e.Handled = true;
            }
            return e.Handled;

        }
        public static bool IsDate(string m_data)
        {
            DateTime m_dataTemp = new DateTime();
            try
            {
                m_dataTemp = DateTime.Parse(m_data);
                return true;
            }

            catch
            {
                return false;
            }

        }

    }
}
