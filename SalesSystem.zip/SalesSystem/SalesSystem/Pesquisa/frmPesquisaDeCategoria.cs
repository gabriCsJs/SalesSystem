﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{
    public partial class frmPesquisaDeCategoria : Form
    {
        public frmPesquisaDeCategoria()
        {
            InitializeComponent();
        }
        public int categoria { get; set; }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            string sql = @"select * from tbl_categoria where (Nome_categoria like '%" + txtLocalizar.Text+ "% ')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frmPesquisaDeCategoria_Load(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
