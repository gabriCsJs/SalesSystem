﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem.Pesquisa
{
    public partial class frmClientePesquisa : Form
    {
        public frmClientePesquisa()
        {
            InitializeComponent();
        }
        public int cliente { get; set; }
        private void frmClientePesquisa_Load(object sender, EventArgs e)
        {

        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            string sql = @"select * from tbl_cliente where (Nome_cli like '%" + txtLocalizar.Text + "% ')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            dataGridView1.DataSource = dt;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                this.cliente = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            }

            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
