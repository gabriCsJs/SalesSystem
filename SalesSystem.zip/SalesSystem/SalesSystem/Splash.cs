﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{ 

    public partial class Splash : Form
    {
        // Lista de textos para exibir na janela splash
        private List<string> textos = new List<string>()
        {
            "Entrando",
            "Verificando requisitos do sistema!",
            "Checando banco de dados!",
            "Verificação concluída com sucesso, aguarde!",
            // Adicione mais textos aqui se desejar
        };

        private int indiceTextoAtual = 0;

        public Splash()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Evento de clique no label, não utilizado neste exemplo
        }

        private void Splash_Load(object sender, EventArgs e)
        {
            // Exibir o texto inicial na janela splash
            label1.Text = textos[indiceTextoAtual];

            // Iniciar o temporizador com intervalo de 2 segundos
            timer2.Interval = 1600; // 2 segundos
            timer2.Start();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Evento de clique na imagem, não utilizado neste exemplo
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           

            if (progressBar1.Value < 100)
            {
               progressBar1.Value = progressBar1.Value + 2;
            }
            else
            {
                timer1.Enabled = false;
                this.Visible = false;



                // Abrir a janela de login
                frmLogin login = new SalesSystem.frmLogin();
                login.Show();
            }   
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            // Atualizar o texto da janela splash
            indiceTextoAtual = (indiceTextoAtual + 1) % textos.Count;
            label1.Text = textos[indiceTextoAtual];
        }
    }
}
