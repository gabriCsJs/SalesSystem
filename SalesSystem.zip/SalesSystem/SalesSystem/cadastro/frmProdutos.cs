﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem.cadastro
{
    public partial class frmProdutos : Form
    {
        public frmProdutos()
        {
            InitializeComponent();
        }

        private void MostraProduto(int _codigo)
        {
            string sql = @"select * from tbl_produto
                            where(id_produto='" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_produto"].ToString();
                txtNome.Text = dt.Rows[0]["Nome_produto"].ToString();
                txtPreco.Text = dt.Rows[0]["Preco"].ToString();
                cboxCategoria.Text = dt.Rows[0]["id_categoria"].ToString();
                cboxMarca.Text = dt.Rows[0]["id_marca"].ToString();
                cboxFornecedor.Text = dt.Rows[0]["id_fornecedor"].ToString();
            }
        }

        private void selecionarfk()
        {
            string sql = @"Select id_categoria, Nome_categoria from tbl_categoria order by Nome_categoria";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);

            cboxCategoria.DisplayMember = "Nome_categoria";
            cboxCategoria.ValueMember = "id_categoria";
            cboxCategoria.DataSource = dt;

        }
        private void frmProdutos_Load(object sender, EventArgs e)
        {
            selecionarfk();
            cboxCategoria.SelectedIndex = -1;
        }

        private void LimpaCampo()
        {
            txtNome.Clear();
            txtCodigo.Clear();
            //txtFornecedor.Clear();
            //txtMarca.Clear();
            txtPreco.Clear();
        }


        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = false;

            txtNome.Enabled = true;
            cboxCategoria.Enabled = true;
            cboxFornecedor.Enabled = true;
            cboxMarca.Enabled = true;
            txtPreco.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            cboxCategoria.Enabled = true;
            cboxFornecedor.Enabled = true;
            cboxMarca.Enabled = true;
            txtPreco.Enabled = true;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            if (txtNome.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o nome!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return;
            }

            if (cboxCategoria.Text == "")
            {
                MessageBox.Show("Valor Invalido Para a Senha!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboxCategoria.Focus();
                return;
            }

            if (cboxFornecedor.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o Cargo!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboxFornecedor.Focus();
                return;
            }

            if (cboxMarca.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o Cargo!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboxMarca.Focus();
                return;
            }


            if (txtPreco.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o Cargo!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPreco.Focus();
                return;
            }


            string sql = "";



            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_usuario set Nome_produto= ' " + txtNome.Text + " ' " +
                                                      ", id_categoria= '" + cboxCategoria.Text + "'" +
                                                      ", id_fornecedor= '" + cboxFornecedor.Text + "'" +
                                                      ", id_marca= '" + cboxMarca.Text + "'" +
                                                      ", preco= '" + txtPreco.Text + "'" +
                    "where (id_produto = ' " + txtCodigo.Text + " ')";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {

                sql = @"insert into tbl_usuario (Nome_produto, id_categoria, id_fornecedor,id_marca,preco)" +
                    "values ( '" + txtNome.Text + " ','" + cboxCategoria.Text + " ', '" + cboxFornecedor.Text + " ','" + cboxMarca.Text + " ','" + txtPreco.Text + " ' )";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("certo!!!  :) ", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtCategoria_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboxCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

