﻿using SalesSystem.Pesquisa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem.cadastro
{
    public partial class frmProdutos : Form
    {
        public frmProdutos()
        {
            InitializeComponent();
        }


        private void MostraProduto(int _codigo)
        {
            string sql = @"select * from tbl_produto
                            where(id_produto='" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_produto"].ToString();
                txtNome.Text = dt.Rows[0]["Nome_produto"].ToString();
                txtPreco.Text = dt.Rows[0]["Preco"].ToString();
                cboxCategoria.Text = dt.Rows[0]["id_categoria"].ToString();
                cboxMarca.Text = dt.Rows[0]["id_marca"].ToString();
                cboxFornecedor.Text = dt.Rows[0]["id_fornecedor"].ToString();
            }
        }

        #region SelecionarFKs
        private void selecionarfkCategoria()
        {
            string sql = @"Select id_categoria, Nome_categoria from tbl_categoria order by Nome_categoria";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);

            cboxCategoria.DisplayMember = "Nome_categoria";
            cboxCategoria.ValueMember = "id_categoria";
            cboxCategoria.DataSource = dt;

        }

        private void selecionarfkMarca()
        {
            string sql = @"Select id_marca, Nome_marca from tbl_marca order by Nome_marca";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);

            cboxMarca.DisplayMember = "Nome_marca";
            cboxMarca.ValueMember = "id_marca";
            cboxMarca.DataSource = dt;

        }

        private void selecionarfkFornecedor()
        {
            string sql = @"Select id_fornecedor, nome_fornecedor from tbl_fornecedor order by nome_fornecedor";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);

            cboxFornecedor.DisplayMember = "nome_fornecedor";
            cboxFornecedor.ValueMember = "id_fornecedor";
            cboxFornecedor.DataSource = dt;

        }

        #endregion
        private void frmProdutos_Load(object sender, EventArgs e)
        {
            selecionarfkCategoria();
            selecionarfkMarca();
            selecionarfkFornecedor();
            cboxCategoria.SelectedIndex = -1;
        }

        private void LimpaCampo()
        {
            txtNome.Clear();
            txtCodigo.Clear();
            //txtFornecedor.Clear();
            //txtMarca.Clear();
            txtPreco.Clear();
        }


        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = false;

            txtNome.Enabled = true;
            cboxCategoria.Enabled = true;
            cboxFornecedor.Enabled = true;
            cboxMarca.Enabled = true;
            txtPreco.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            cboxCategoria.Enabled = true;
            cboxFornecedor.Enabled = true;
            cboxMarca.Enabled = true;
            txtPreco.Enabled = true;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            if (txtNome.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o nome!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return;
            }

            if (cboxCategoria.Text == "")
            {
                MessageBox.Show("Valor Invalido Para a Senha!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboxCategoria.Focus();
                return;
            }

            if (cboxFornecedor.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o Cargo!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboxFornecedor.Focus();
                return;
            }

            if (cboxMarca.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o Cargo!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboxMarca.Focus();
                return;
            }


            if (txtPreco.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o Cargo!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPreco.Focus();
                return;
            }

            double preco = 0;

            if (SalesSystem.Clases.Util.isNumber(txtPreco.Text))
            {
                preco = Convert.ToDouble(txtPreco.Text);
            }



            string sql = "";



            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_produto set Nome_produto= ' " + txtNome.Text + " ' " +
                                                      ", id_categoria= '" + cboxCategoria.SelectedValue + "'" +
                                                      ", id_fornecedor= '" + cboxFornecedor.SelectedValue + "'" +
                                                      ", id_marca= '" + cboxMarca.SelectedValue + "'" +
                                                      ", preco= '" + preco.ToString().Replace(".","").Replace(",",".")+ "'" +
                    "where (id_produto = ' " + txtCodigo.Text + " ')";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {

                sql = @"insert into tbl_produto (Nome_produto, id_categoria, id_fornecedor,id_marca,preco)" +
                    "values ( '" + txtNome.Text + " ','" + cboxCategoria.SelectedValue + " ', '" + cboxFornecedor.SelectedValue + " ','" + cboxMarca.SelectedValue + " ','" + preco.ToString().Replace(".","").Replace(",",".") + " ' )";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("certo!!!  :) ", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtCategoria_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboxCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "")
            {
                string sql = "DELETE FROM tbl_produto WHERE id_produto = '" + txtCodigo.Text + "'";
                SalesSystem.Clases.db.ExecutaComando(sql, false);

                MessageBox.Show("Item excluído com sucesso!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaCampo();
            }
            else
            {
                MessageBox.Show("Selecione um item para excluir!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = false;
            cboxCategoria.Enabled = false;
            cboxFornecedor.Enabled = false;
            cboxMarca.Enabled = false;
            txtPreco.Enabled = false;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = false;
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            cboxCategoria.Enabled = true;
            cboxFornecedor.Enabled = true;
            cboxMarca.Enabled = true;
            txtPreco.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            frmProdutoPesquisar cat = new frmProdutoPesquisar();
            cat.ShowDialog();

            if (cat.Produto > 0)
            {
                MostraProduto(cat.Produto);
            }
        }

        private void cboxCategoria_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
    }

