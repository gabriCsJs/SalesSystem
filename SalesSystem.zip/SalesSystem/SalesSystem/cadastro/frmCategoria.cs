﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{
    public partial class frmCategoria : Form
    {
        public frmCategoria()
        {
            InitializeComponent();
        }


        private void LimpaCampo()
        {
            txtCategoria.Clear();
            txtCodigo.Clear();
        }

        private void MostraCategoria(int _codigo)
        {
            string sql = @"select * from tbl_categoria
                            where(id_categoria='" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_categoria"].ToString();
                txtCategoria.Text = dt.Rows[0]["Nome_categoria"].ToString();
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;

            txtCategoria.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtCategoria.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o nome!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCategoria.Focus();
                return;
            }

        

            string sql = "";

            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_categoria set Nome_categoria= ' " + txtCategoria.Text + "'"+
                    "where (id_categoria= ' " + txtCodigo.Text + " ')";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {
                sql = @"insert into tbl_categoria (Nome_categoria)"+
                    "values ( '" + txtCategoria.Text + " ' )";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("certo!!!  :) ", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtCategoria.Enabled = false;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = false;
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "")
            {
                string sql = "DELETE FROM tbl_categoria WHERE id_categoria = '" + txtCodigo.Text + "'";
                SalesSystem.Clases.db.ExecutaComando(sql, false);

                MessageBox.Show("Item excluído com sucesso!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaCampo();

            }
            else
            {
                MessageBox.Show("Selecione um item para excluir!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;

            txtCategoria.Enabled = false;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            frmPesquisaDeCategoria cat = new frmPesquisaDeCategoria();
            cat.ShowDialog();

            if (cat.categoria > 0)
            {
                MostraCategoria(cat.categoria);
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCategoria_Load(object sender, EventArgs e)
        {

        }
    }
}
