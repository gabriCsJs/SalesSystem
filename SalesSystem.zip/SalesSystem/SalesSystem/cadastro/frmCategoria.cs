﻿using SalesSystem;
using SalesSystem.Pesquisa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{
    public partial class frmCategoria : Form
    {
        public frmCategoria()
        {
            InitializeComponent();
        }


        private void LimpaCampo()
        {
            txtCategoria.Clear();
            txtCodigo.Clear();
        }

       /* private void MostraCategoria(int _codigo)
        {
            string sql = @"select * from tbl_categoria
                            where(id_categoria='" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_categoria"].ToString();
                txtCategoria.Text = dt.Rows[0]["Nome_categoria"].ToString();
            }

        }*/

        private void localiza(int _codigo)
        {
            string sql = @"select id_categoria, Nome_categoria from tbl_categoria2
                            where (id_categoria = '" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCategoria.Text = dt.Rows[0]["Nome_categoria"].ToString();
                txtCodigo.Text = dt.Rows[0]["id_categoria"].ToString();
            }
        }



        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;

            txtCategoria.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtCategoria.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o nome!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCategoria.Focus();
                return;
            }

        

            string sql = "";

            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_categoria2 set Nome_categoria= ' " + txtCategoria.Text + "'"+
                    "where (id_categoria= ' " + txtCodigo.Text + " ')";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {
                sql = @"insert into tbl_categoria2 (Nome_categoria)" +
                    "values ( '" + txtCategoria.Text + " ' )";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("certo!!!  :) ", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtCategoria.Enabled = false;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = false;
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "")
            {
                string sql = "DELETE FROM tbl_categoria2 WHERE id_categoria = '" + txtCodigo.Text + "'";
                SalesSystem.Clases.db.ExecutaComando(sql, false);

                MessageBox.Show("Item excluído com sucesso!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaCampo();

            }
            else
            {
                MessageBox.Show("Selecione um item para excluir!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        
        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;

            txtCategoria.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            frmPesquisar f = new frmPesquisar ();
            f.Tabela = "tbl_categoria2";
            f.AddCampos("Nome_categoria", "Nome");
            f.AddCampos("id_categoria", "codigo");

            f.AddColunas("Nome_categoria", "Nome", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("id_categoria", "codigo", 50, DataGridViewContentAlignment.MiddleLeft, "");

            f.SQL = @"select tbl_categoria2.id_categoria, tbl_categoria2.Nome_categoria
		                from tbl_categoria2";

            f.ShowDialog();

            if (f.CodRetorno != string.Empty)
            {
                localiza(Convert.ToInt32(f.CodRetorno));
            }


            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmCategoria_Load(object sender, EventArgs e)
        {

        }
    }
}
