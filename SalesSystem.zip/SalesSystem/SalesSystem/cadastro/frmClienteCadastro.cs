﻿//using SalesSystem.Pesquisa;
using SalesSystem.Pesquisa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace SalesSystem
{
    public partial class frmClienteCadastro : Form
    {
        public frmClienteCadastro()
        {
            InitializeComponent();
        }

        private void frmClienteCadastro_Load(object sender, EventArgs e)
        {

        }

        private void localiza(int _codigo)
        {
            string sql = @"select id_cliente, Nome_cli, cpf, idade, rg, sexo, celular
		                from tbl_cliente
                        where (id_cliente = '" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_cliente"].ToString();
                txtNome.Text = dt.Rows[0]["Nome_cli"].ToString();
                txtCelular.Text = dt.Rows[0]["celular"].ToString();
                txtCpf.Text = dt.Rows[0]["cpf"].ToString();
                txtIdade.Text = dt.Rows[0]["idade"].ToString();
                txtRG.Text = dt.Rows[0]["rg"].ToString();
                txtSexo.Text = dt.Rows[0]["sexo"].ToString();
            }
        }

        private void LimpaCampo()
        {
            txtNome.Clear();
            txtCodigo.Clear();
            txtCpf.Clear();
            txtIdade.Clear();
            txtRG.Clear();
            txtSexo.Clear();
            txtCelular.Clear();
        }


        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            txtCelular.Enabled = true;
            txtCpf.Enabled = true;
            txtIdade.Enabled = true;
            txtRG.Enabled = true;
            txtSexo.Enabled = true;

            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "")
            {
                string sql = "DELETE FROM tbl_cliente WHERE id_cliente = '" + txtCodigo.Text + "'";
                SalesSystem.Clases.db.ExecutaComando(sql, false);

                MessageBox.Show("Item excluído com sucesso!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaCampo();
            }
            else
            {
                MessageBox.Show("Selecione um item para excluir!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            txtCelular.Enabled = true;
            txtCpf.Enabled = true;
            txtIdade.Enabled = true;
            txtRG.Enabled = true;
            txtSexo.Enabled = true;

            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            if (txtNome.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o nome!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return;
            }

            string sql = "";



            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_cliente set Nome_cli= ' " + txtNome.Text + " ' " +
                                                      ", celular= '" + txtCelular.Text + "'" +
                                                      ", cpf= '" + txtCpf.Text + "'" +
                                                      ", idade= '" + txtIdade.Text + "'" +
                                                      ", rg= '" + txtRG.Text + "'" +
                                                      ", sexo= '" + txtSexo.Text + "'" +
                    "where (id_cliente = ' " + txtCodigo.Text + " ')";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {

                sql = @"insert into tbl_cliente (Nome_cli, celular, cpf, idade, rg, sexo)" +
                    "values ( '" + txtNome.Text + " ','" + txtCelular.Text + " ', '" + txtCpf.Text + " ','" + txtIdade.Text + " ','" + txtRG.Text + " ','" + txtSexo.Text + " ' )";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("certo!!!  :) ", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = false;
            txtCelular.Enabled = false;
            txtCpf.Enabled = false;
            txtIdade.Enabled = false;
            txtRG.Enabled = false;
            txtSexo.Enabled = false;

            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = false;
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;


            txtNome.Enabled = true;
            txtCelular.Enabled = true;
            txtCpf.Enabled = true;
            txtIdade.Enabled = true;
            txtRG.Enabled = true;
            txtSexo.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;


            frmPesquisar f = new frmPesquisar();
            f.Tabela = "tbl_cliente ";
            f.AddCampos("id_cliente ", "codigo");
            f.AddCampos("Nome_cli ", "nome");
            f.AddCampos("celular ", "celular");
            f.AddCampos("cpf ", "cpf");
            f.AddCampos("idade, ", "idade, ");
            f.AddCampos("rg", "rg");
            f.AddCampos("sexo ", "sexo");

            f.AddColunas("id_cliente", "Código", 50, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("Nome_cli", "Nome", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("celular", "cnpj", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("cpf", "cpf", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("idade", "idade", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("rg", "rg", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("sexo", "sexo", 200, DataGridViewContentAlignment.MiddleLeft, "");

            f.SQL = @"select tbl_cliente.id_cliente, tbl_cliente.Nome_cli, tbl_cliente.cpf, tbl_cliente.idade, tbl_cliente.rg, tbl_cliente.sexo, tbl_cliente.celular
		                from tbl_cliente";

            f.ShowDialog();

            if (f.CodRetorno != string.Empty)
            {
                localiza(Convert.ToInt32(f.CodRetorno));
            }

            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

        }
    }
}
