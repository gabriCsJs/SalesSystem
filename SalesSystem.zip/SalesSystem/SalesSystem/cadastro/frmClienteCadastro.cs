﻿using SalesSystem.Pesquisa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace SalesSystem
{
    public partial class frmClienteCadastro : Form
    {
        public frmClienteCadastro()
        {
            InitializeComponent();
        }

        private void frmClienteCadastro_Load(object sender, EventArgs e)
        {

        }

        private void MostraCliente(int _codigo)
        {
            string sql = @"select * from tbl_cliente
                            where(id_cliente='" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_cliente"].ToString();
                txtNome.Text = dt.Rows[0]["Nome_cli"].ToString();
                txtCelular.Text = dt.Rows[0]["celular"].ToString();
                txtCpf.Text = dt.Rows[0]["cpf"].ToString();
                txtIdade.Text = dt.Rows[0]["idade"].ToString();
                txtRG.Text = dt.Rows[0]["rg"].ToString();
                txtSexo.Text = dt.Rows[0]["sexo"].ToString();
                 
            }
        }

        private void LimpaCampo()
        {
            txtNome.Clear();
            txtCodigo.Clear();
            txtCpf.Clear();
            txtIdade.Clear();
            txtRG.Clear();
            txtSexo.Clear();
            txtCelular.Clear();
        }


        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = false;

            txtNome.Enabled = true;
            txtCelular.Enabled = true;
            txtCpf.Enabled = true;
            txtIdade.Enabled = true;
            txtRG.Enabled = true;
            txtSexo.Enabled = true;

            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "")
            {
                string sql = "DELETE FROM tbl_usuario WHERE id_usuario = '" + txtCodigo.Text + "'";
                SalesSystem.Clases.db.ExecutaComando(sql, false);

                MessageBox.Show("Item excluído com sucesso!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaCampo();
            }
            else
            {
                MessageBox.Show("Selecione um item para excluir!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            txtCelular.Enabled = true;
            txtCpf.Enabled = true;
            txtIdade.Enabled = true;
            txtRG.Enabled = true;
            txtSexo.Enabled = true;

            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            if (txtNome.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o nome!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return;
            }

            string sql = "";



            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_cliente set Nome_cli= ' " + txtNome.Text + " ' " +
                                                      ", celular= '" + txtCelular.Text + "'" +
                                                      ", cpf= '" + txtCpf.Text + "'" +
                                                      ", idade= '" + txtIdade.Text + "'" +
                                                      ", rg= '" + txtRG.Text + "'" +
                                                      ", sexo= '" + txtSexo.Text + "'" +
                    "where (id_cliente = ' " + txtCodigo.Text + " ')";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {

                sql = @"insert into tbl_cliente (Nome_cli, celular, cpf, idade, rg, sexo)" +
                    "values ( '" + txtNome.Text + " ','" + txtCelular.Text + " ', '" + txtCpf.Text + " ','" + txtIdade.Text + " ','" + txtRG.Text + " ','" + txtSexo.Text + " ' )";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("certo!!!  :) ", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            txtCelular.Enabled = true;
            txtCpf.Enabled = true;
            txtIdade.Enabled = true;
            txtRG.Enabled = true;
            txtSexo.Enabled = true;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = false;
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;


            txtNome.Enabled = true;
            txtCelular.Enabled = true;
            txtCpf.Enabled = true;
            txtIdade.Enabled = true;
            txtRG.Enabled = true;
            txtSexo.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            frmClientePesquisa cat = new frmClientePesquisa();
            cat.ShowDialog();

            if (cat.cliente > 0)
            {
                MostraCliente(cat.cliente);
            }
        }
    }
}
