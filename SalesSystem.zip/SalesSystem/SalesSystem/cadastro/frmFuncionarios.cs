﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem.cadastro
{
    public partial class frmFuncionarios : Form
    {
        public frmFuncionarios()
        {
            InitializeComponent();
        }


        private void frmFuncionarios_Load(object sender, EventArgs e)
        {

        }

        private void Mostrafuncionario(int _codigo)
        {
            string sql = @"select * from tbl_usuario
                            where(id_usuario='" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_usuario"].ToString();
                txtNome.Text = dt.Rows[0]["Nome_usuario"].ToString();
                txtSenha.Text = dt.Rows[0]["Senha_u"].ToString();
                txtCargo.Text = dt.Rows[0]["cargo"].ToString();
            }
        }

        private void LimpaCampo()
        {
            txtNome.Clear();
            txtCodigo.Clear();
            txtCargo.Clear();
            txtSenha.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = false;

            txtNome.Enabled = true;
            txtSenha.Enabled = true;
            txtCargo.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            txtSenha.Enabled = true;
            txtCargo.Enabled = true;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            if (txtNome.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o nome!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return;
            }

            if (txtSenha.Text == "")
            {
                MessageBox.Show("Valor Invalido Para a Senha!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSenha.Focus();
                return;
            }

            if (txtCargo.Text == "")
            {
                MessageBox.Show("Valor Invalido Para o Cargo!", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCargo.Focus();
                return;
            }

            string sql = "";



            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_usuario set Nome_usuario= ' " + txtNome.Text + " ' " +
                                                      ", cargo= '" + txtCargo.Text + "'" +
                                                      ", Senha_u= '" + txtSenha.Text + "'" +
                    "where (id_usuario = ' " + txtCodigo.Text + " ')";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {

                sql = @"insert into tbl_usuario (Nome_usuario, Senha_u, cargo)" +
                    "values ( '" + txtNome.Text + " ','" + txtSenha.Text + " ', '" + txtCargo.Text + " ' )";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("certo!!!  :) ", "atençao", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = false;
            txtSenha.Enabled = false;
            txtCargo.Enabled = false;
            btnCancelar.Enabled = false;
            btnExcluir.Enabled = false;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "")
            {
                string sql = "DELETE FROM tbl_usuario WHERE id_usuario = '" + txtCodigo.Text + "'";
                SalesSystem.Clases.db.ExecutaComando(sql, false);

                MessageBox.Show("Item excluído com sucesso!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaCampo();
            }
            else
            {
                MessageBox.Show("Selecione um item para excluir!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLocalizar_Click_1(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = true;

            txtNome.Enabled = true;
            txtSenha.Enabled = true;
            txtCargo.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;

            frmFuncionariosPesquisa cat = new frmFuncionariosPesquisa();
            cat.ShowDialog();

            if (cat.funcionario > 0)
            {
                Mostrafuncionario(cat.funcionario);
            }
        }
    }
    }

