﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{
    public partial class frmFornecedorCadastro : Form
    {
        public frmFornecedorCadastro()
        {
            InitializeComponent();
        }

        private void MostraCliente(int _codigo)
        {
            string sql = @"select * from tbl_cliente
                            where(id_cliente='" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtCodigo.Text = dt.Rows[0]["id_cliente"].ToString();
                txtNome.Text = dt.Rows[0]["Nome_cli"].ToString();
                txtCelular.Text = dt.Rows[0]["celular"].ToString();
                txtCpf.Text = dt.Rows[0]["cpf"].ToString();
                txtIdade.Text = dt.Rows[0]["idade"].ToString();
                txtRG.Text = dt.Rows[0]["rg"].ToString();
                txtSexo.Text = dt.Rows[0]["sexo"].ToString();

            }
        }

        private void LimpaCampo()
        {

        }

        private void frmFornecedorCadastro_Load(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            LimpaCampo();
            btnNovo.Enabled = false;
            btnLocalizar.Enabled = false;

            txtNome.Enabled = true;
            txtSenha.Enabled = true;
            txtCargo.Enabled = true;
            btnCancelar.Enabled = true;
            btnExcluir.Enabled = true;
            btnFechar.Enabled = true;
            btnSalvar.Enabled = true;
        }
    }
}
