﻿using SalesSystem;
using SalesSystem.Pesquisa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{
    public partial class frmFornecedorCadastro : Form
    {
        public frmFornecedorCadastro()
        {
            InitializeComponent();
        }



        private void localiza(int _codigo)
        {
            string sql = @"select id_fornecedor, nome_fornecedor, cnpj, endereco, bairro, cidade, cep, id_estado from tbl_fornecedor 
                            where (id_fornecedor = '" + _codigo + "')";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            if (dt.Rows.Count > 0 && dt.Rows[0][0].ToString() != "")
            {
                txtBairro.Text = dt.Rows[0]["bairro"].ToString();
                txtCep.Text = dt.Rows[0]["cep"].ToString();
                txtCidade.Text = dt.Rows[0]["cidade"].ToString();
                txtCodigo.Text = dt.Rows[0]["id_fornecedor"].ToString();
                txtEndereco.Text = dt.Rows[0]["endereco"].ToString();
                txtNome.Text = dt.Rows[0]["nome_fornecedor"].ToString();
                txtCNPJ.Text = dt.Rows[0]["cnpj"].ToString();
                cboxEstado.Text = dt.Rows[0]["id_estado"].ToString();
            }
        }

        private void selecionarfkEstado()
        {
            string sql = @"Select id_estado, Nome_estado from tbl_estado order by Nome_estado";
            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);

            cboxEstado.DisplayMember = "Nome_estado";
            cboxEstado.ValueMember = "id_estado";
            cboxEstado.DataSource = dt;

        }

        private void limpaCampo()
        {
            txtBairro.Clear();
            txtCep.Clear();
            txtCelular.Clear();
            txtCidade.Clear();
            txtCNPJ.Clear();
            txtCodigo.Clear();
            txtEndereco.Clear();
            txtNome.Clear();
            txtNumero.Clear();
            cboxEstado.SelectedValue = -1;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            limpaCampo();

            btnCancelar.Enabled = true;
            btnSalvar.Enabled = true;
            btnFechar.Enabled = true;
            btnLocalizar.Enabled = true;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = true;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            limpaCampo();

            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;
            btnFechar.Enabled = true;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Valor inválido para o campo Nome!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = "";

            if (txtCodigo.Text != "")
            {
                sql = @"update tbl_fornecedor set nome_fornecedor= '" + txtNome.Text + "'" +
                                                                 ", endereco= '" + txtEndereco.Text + "'" +
                                                                 ", cnpj= '" + txtCNPJ.Text + "'" +
                                                                 ", bairro= '" + txtBairro.Text + "'" +
                                                                 ", cidade= '" + txtCidade.Text + "'" +
                                                                 ", cep= '" + txtCep.Text + "'" +
                                                                 ", id_estado= '" + cboxEstado.SelectedValue + "'" +
                                                                 "where (id_fornecedor= '" + txtCodigo.Text + "')";
                    SalesSystem.Clases.db.ExecutaComando(sql, false);
            }

            else
            {
                sql = @"insert into tbl_fornecedor (nome_fornecedor, cnpj, endereco, bairro, cidade, cep, id_estado)" +
                                    "values ('" + txtNome.Text + "','" + txtCNPJ.Text + "','" + txtEndereco.Text + "','" + txtBairro.Text + "','" + txtCidade.Text + "','" + txtCep.Text + "','" + cboxEstado.SelectedValue + "')";
                int cod = SalesSystem.Clases.db.ExecutaComando(sql, true);
                txtCodigo.Text = cod.ToString();
            }

            MessageBox.Show("Informações salva com sucesso!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);

            btnNovo.Enabled = true;
            btnLocalizar.Enabled = true;
            btnFechar.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "" && MessageBox.Show("Deseja excluir este registro?", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == System.Windows.Forms.DialogResult.Yes)
            {
                string sql = @"delete from tbl_fornecedor where (id_fornecedor=" + txtCodigo.Text + ")";
                SalesSystem.Clases.db.ExecutaComando(sql, false);
                limpaCampo();
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            btnCancelar.Enabled = true;
            btnSalvar.Enabled = true;
            btnFechar.Enabled = true;
            btnLocalizar.Enabled = true;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = true;

            frmPesquisar f = new frmPesquisar();
            f.Tabela = "tbl_fornecedor";
            f.AddCampos("id_fornecedor", "codigo");
            f.AddCampos("nome_fornecedor", "Fornecedor");
            f.AddCampos("cnpj", "CPNJ");
            f.AddCampos("endereco", "Endereco");
            f.AddCampos("bairro", "Bairro");
            f.AddCampos("cidade", "Cidade");
            f.AddCampos("cep", "Cep");
            f.AddCampos("id_estado", "Estado");

            f.AddColunas("id_fornecedor", "Código", 50, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("nome_fornecedor", "Nome", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("cnpj", "cnpj", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("endereco", "endereco", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("bairro", "bairro", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("cidade", "cidade", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("cep", "cep", 200, DataGridViewContentAlignment.MiddleLeft, "");
            f.AddColunas("id_estado", "estado", 200, DataGridViewContentAlignment.MiddleLeft, "");

            f.SQL = @"select tbl_fornecedor.id_fornecedor, tbl_fornecedor.nome_fornecedor, tbl_fornecedor.cnpj, tbl_fornecedor.endereco, tbl_fornecedor.bairro, tbl_fornecedor.cidade, tbl_fornecedor.cep, tbl_fornecedor.id_estado
		                from tbl_fornecedor";

            f.ShowDialog();

            if (f.CodRetorno != string.Empty)
            {
                localiza(Convert.ToInt32(f.CodRetorno));
            }


            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;
        }

        private void frmFornecedorCadastro_Load(object sender, EventArgs e)
        {
            selecionarfkEstado();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}