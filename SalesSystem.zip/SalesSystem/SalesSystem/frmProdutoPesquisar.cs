﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesSystem
{
    public partial class frmProdutoPesquisar : Form
    {
        public frmProdutoPesquisar()
        {
            InitializeComponent();
        }

        public int Produto { get; set; }

        private void frmProdutoPesquisar_Load(object sender, EventArgs e)
        {
            
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                this.Produto = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            }

            this.Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {

           // string sql = @"select * from tbl_produto2 where (Nome_produto like '%" + txtLocalizar.Text + "% ')";
            string sql = @"select  tbl_produto2.Nome_produto, tbl_marca.Nome_marca
                            from tbl_produto2
                            inner join tbl_marca 
                            on tbl_produto2.id_marca = tbl_marca.id_marca";

            DataTable dt = SalesSystem.Clases.db.RetornaDataTable(sql);
            dataGridView1.DataSource = dt;

        }
    }
}
